from mods.hydrogen import utils, events

# Import mod 'example'.
utils.import_mod("example")


# Object to store event data.
class data:
  name = "Zombie"


# Call event OnKill in all mods with the data from the data object.
return_value = utils.call_event(events.OnKill, data)